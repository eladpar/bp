V5: No tag_bits=0.
Found a mistake?
Contact via mail shemadolev@campus.technion.ac.il
or http://t.me/shemadolev